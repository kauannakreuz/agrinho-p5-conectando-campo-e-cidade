let campoPeople = [];
let cidadePeople = [];
let connections = [];
let selected = null;
let score = 0;
let gameState = "capa";  // Inicia no estado "capa"

let symbols = ["🌽", "🍎", "🌻"];
let connectionEmoji = "🤝";  // Emoji para a conexão

function setup() {
  createCanvas(800, 400);
  textAlign(CENTER, CENTER);
  textSize(32);

  // Criar pessoas do campo
  for (let i = 0; i < 3; i++) {
    campoPeople.push({
      x: 100,
      y: 100 + i * 100,
      symbol: symbols[i],
      matched: false
    });
  }

  // Criar pessoas da cidade
  for (let i = 0; i < 3; i++) {
    cidadePeople.push({
      x: 700,
      y: 100 + i * 100,
      symbol: symbols[i],
      matched: false
    });
  }
}

function draw() {
  background(220);

  if (gameState === "play") {
    drawScene(); // Função que desenha o fundo estilizado
    drawPeople();
    drawConnections();

    fill(0);
    textSize(16);
    text("Conexões feitas: " + score, width / 2, 20);

    if (score >= 3) {
      gameState = "festa";
    }
  } else if (gameState === "festa") {
    showFesta();
  } else if (gameState === "instrucoes") {
    showInstrucoes(); // Tela de instruções
  } else if (gameState === "capa") {
    showCapa();  // Tela inicial com explicação do jogo
  }
}

function drawScene() {
  // Fundo - Céu e linha do horizonte
  drawSkyAndHorizon();

  // Campo (lado esquerdo)
  fill(120, 200, 120); // Cor verde para o campo
  rect(0, height / 2, width / 2, height / 2); // Campo
  fill(0);
  text("🌾 CAMPO", width / 4, 30);

  // Adicionando árvores no campo
  for (let i = 50; i < width / 2; i += 100) {
    drawTree(i, height / 2 + 50);
  }

  // Cidade (lado direito)
  fill(180); // Cor mais neutra para a cidade
  rect(width / 2, height / 2, width / 2, height / 2); // Cidade
  fill(0);
  text("🏙️ CIDADE", width - width / 4, 30);

  // Adicionando prédios na cidade
  for (let i = width / 2 + 50; i < width - 50; i += 100) {
    drawBuilding(i, height / 2 + 20);
  }

  // Linha divisória entre campo e cidade
  stroke(0);
  line(width / 2, 0, width / 2, height);
  noStroke();
}

function drawSkyAndHorizon() {
  // Criando o céu (gradiente)
  for (let i = 0; i < height / 2; i++) {
    let inter = map(i, 0, height / 2, 0, 1);
    let c = lerpColor(color(135, 206, 235), color(255, 204, 0), inter); // Gradiente do céu
    stroke(c);
    line(0, i, width, i); // Linha horizontal para o céu
  }

  // Criando o horizonte (divisão entre o céu e a terra)
  fill(60, 60, 60); // Cor do horizonte
  noStroke();
  rect(0, height / 2 - 10, width, 20); // Linha do horizonte
}

function drawTree(x, y) {
  // Desenha uma árvore simples
  fill(139, 69, 19); // Cor do tronco
  rect(x, y, 10, 30); // Tronco
  fill(34, 139, 34); // Cor das folhas
  ellipse(x + 5, y - 10, 40, 40); // Folhas
}

function drawBuilding(x, y) {
  // Desenha um prédio simples
  fill(169, 169, 169);
  rect(x, y, 40, 60);
  fill(255);
  for (let j = 0; j < 3; j++) {
    for (let k = 0; k < 3; k++) {
      rect(x + 5 + k * 10, y + 5 + j * 15, 8, 12); // Janelas
    }
  }
}

function drawPeople() {
  for (let p of campoPeople) {
    if (!p.matched) {
      fill(100);
      ellipse(p.x, p.y, 60, 60);
      text(p.symbol, p.x, p.y);
    }
  }

  for (let p of cidadePeople) {
    if (!p.matched) {
      fill(100);
      ellipse(p.x, p.y, 60, 60);
      text(p.symbol, p.x, p.y);
    }
  }
}

function drawConnections() {
  stroke(0, 150, 255);
  strokeWeight(3);
  for (let c of connections) {
    // Desenha a linha entre as pessoas conectadas
    line(c.a.x, c.a.y, c.b.x, c.b.y);

    // Desenha o emoji de conexão no meio da linha
    let midX = (c.a.x + c.b.x) / 2;
    let midY = (c.a.y + c.b.y) / 2;
    textSize(24);
    text(connectionEmoji, midX, midY); // Coloca o emoji de conexão no meio da linha
  }
  noStroke();
}

function mousePressed() {
  if (gameState === "capa") {
    gameState = "instrucoes"; // Muda para a tela de instruções
  } else if (gameState === "instrucoes") {
    gameState = "play"; // Começa o jogo após as instruções
  } else if (!selected) {
    for (let p of campoPeople.concat(cidadePeople)) {
      if (!p.matched && dist(mouseX, mouseY, p.x, p.y) < 30) {
        selected = p;
        break;
      }
    }
  } else {
    // Tentar conectar com outro
    for (let p of campoPeople.concat(cidadePeople)) {
      if (!p.matched && p !== selected && dist(mouseX, mouseY, p.x, p.y) < 30) {
        if (p.symbol === selected.symbol) {
          // Conectou com sucesso
          connections.push({ a: selected, b: p });
          selected.matched = true;
          p.matched = true;
          score++;
        }
        selected = null;
        return;
      }
    }
    selected = null;
  }
}

function showFesta() {
  background(30, 20, 50);
  fill(255);
  textSize(32);
  text("🎉 Conexão Campo-Cidade 🎉", width / 2, height / 2 - 20);
  textSize(16);
  text("Produção rural + Consumo urbano = Comunidade forte!", width / 2, height / 2 + 20);

  // Fogos de artifício simples
  for (let i = 0; i < 10; i++) {
    fill(random(255), random(255), random(255));
    ellipse(random(width), random(height), random(5, 15));
  }
}

function showInstrucoes() {
  background(220);

  // Texto explicativo sobre como jogar
  fill(0);
  textSize(24);
  text("Como jogar:", width / 2, 40);
  
  textSize(16);
  text("1. Clique nos emojis do campo e da cidade.", width / 2, 80);
  text("2. Conecte os emojis com o mesmo símbolo.", width / 2, 110);
  text("3. Complete as conexões para ganhar pontos.", width / 2, 140);
  
  textSize(14);
  text("O objetivo é conectar todos os emojis com o mesmo símbolo.", width / 2, 170);
  
  // Mensagem para começar o jogo
  fill(0);
  textSize(20);
  text("Clique para começar!", width / 2, height - 50);
}

function showCapa() {
  background(220);
  
  // Texto explicativo
  fill(0);
  textSize(24);
  text("🌾 CAMPO ↔ CIDADE 🏙️", width / 2, 40);
  
  textSize(16);
  text("A conexão entre o campo e a cidade é fundamental para a sociedade moderna.", width / 2, 80);
  text("Produção rural + Consumo urbano = Comunidade forte!", width / 2, 110);
  
  textSize(14);
  text("A cidade depende do campo para sua alimentação e produtos.", width / 2, 140);
  text("O campo depende da cidade para o mercado, serviços e inovação.", width / 2, 170);
  
  // Ilustração com a divisão
  fill(120, 200, 120);
  rect(0, height / 2, width / 2, height / 2);
  fill(180);
  rect(width / 2, height / 2, width / 2, height / 2);
  
  // Emoji de Conexão
  textSize(32);
  text("🤝", width / 2, height / 2);

  // Mensagem para começar o jogo
  fill(0);
  textSize(20);
  text("Clique aqui para começar!", width / 2, height - 50);
}
